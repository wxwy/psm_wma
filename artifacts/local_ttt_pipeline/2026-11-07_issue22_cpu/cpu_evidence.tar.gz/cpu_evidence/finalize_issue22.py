"""Verify and package the frozen Child's local author evidence; no project imports."""
from pathlib import Path
import ast
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

root = Path('/workspace/work/psm-wma-local-ttt-pipeline-issue22')
child = root/'cosmos-framework'
base = Path('/workspace/work/issue22-pipeline-evidence')
candidate = '5fe2b8def58f4caae8c63581ed3649ac8fb3e0c6'
context = '631a36225f4d4d93ffe30076ea95a2f890085363'
baseline_root = '8aeb2442993620ee4513834a73064a4ea1eca38c'
baseline_child = '1ca308055fc41fb69efaeb9efaa23808f164a18e'

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()

def read_json(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert git(child,'rev-parse','HEAD') == candidate and not git(child,'status','--porcelain')
assert git(root,'rev-parse','HEAD') == context
assert git(root,'rev-parse','HEAD:cosmos-framework') == baseline_child
assert git(root,'status','--porcelain') == 'M cosmos-framework'
files = git(child,'diff','--name-only',baseline_child,candidate).splitlines()
assert len(files) == 20 and sum(path.endswith('_test.py') for path in files) == 8
assert files == read_json(base/'static-04/summary.json')['files']
assert all(path.startswith(('cosmos_framework/inference/','cosmos_framework/scripts/','cosmos_framework/simulation/robocasa/')) for path in files)
protected={}
for tree in ['model','trainer','configs','checkpoint','data','evaluation']:
    path='cosmos_framework/'+tree
    old=git(child,'rev-parse',baseline_child+':'+path)
    assert old == git(child,'rev-parse',candidate+':'+path)
    protected[path]=old
assert all(path in ('SESSION.md','TODO.md') or path.startswith('docs/') for path in git(root,'diff','--name-only',baseline_root,context).splitlines())
stage_summaries={}
for name,expected in [('g0-visual',(6,0,0)),('development-01',(426,4,1)),('focused-02',(35,0,0)),('service-wiring',(1,0,0)),('author-final',(428,0,0))]:
    directory=base/name
    result=read_json(directory/'summary.json')
    assert (result['tests'],result['failures'],result['exit_code']) == expected
    assert result['errors'] == result['skipped'] == 0 and result['source_unchanged']
    before=read_json(directory/'source_before.json')
    assert before == read_json(directory/'source_after.json')
    stage_summaries[name]=result
before=read_json(base/'author-final/source_before.json')
assert before['root'] == context and before['child'] == candidate
assert before['child_status'] == '' and before['root_status'] == 'M cosmos-framework'
assert baseline_child in before['gitlink'] and before['gitlink'].endswith('cosmos-framework')
assert len(before['sha256']) == 1273
for path,digest in before['sha256'].items():
    assert sha(root/path) == digest,path
junit=ET.parse(base/'author-final/junit.xml')
cases=list(junit.iter('testcase'))
assert len(cases)==len({(case.get('file'),case.get('name')) for case in cases})==428
assert not any(list(junit.iter(tag)) for tag in ['failure','error','skipped'])
new_files={Path(path).name for path in files if path.endswith('_test.py')}
counts={name:sum(case.get('file','').endswith('/'+name) for case in cases) for name in sorted(new_files)}
assert sum(counts.values())==155
properties={}
for prop in junit.iter('property'):
    if prop.get('name') in ('issue22_scan_parity','issue22_online_parity','issue22_g0_actual_wan_cpu'):
        properties.setdefault(prop.get('name'),[]).append(json.loads(prop.get('value')))
assert [len(properties[name]) for name in ['issue22_scan_parity','issue22_online_parity','issue22_g0_actual_wan_cpu']] == [12,3,2]
for name in ('issue22_scan_parity','issue22_online_parity'):
    assert all(record['prefix_max_abs']==record['state_max_abs']==0 for record in properties[name])
assert all(record['action_max_abs']==0 for record in properties['issue22_online_parity'])
static=base/'final-static'
static.mkdir(exist_ok=False)
checks=[]
for label,command in [
    ('ruff',[sys.executable,'-m','ruff','check','--no-cache',*files]),
    ('format',[sys.executable,'-m','ruff','format','--check','--no-cache',*files]),
    ('diff_check',['git','diff','--check',baseline_child,candidate]),
]:
    completed=subprocess.run(command,cwd=child,capture_output=True,text=True)
    (static/(label+'.log')).write_text(completed.stdout+completed.stderr)
    assert completed.returncode==0,(label,completed.stdout,completed.stderr)
    checks.append({'name':label,'command':command,'exit_code':0})
for path in files:
    ast.parse((child/path).read_bytes())
(static/'child_delta.patch').write_text(git(child,'diff',baseline_child,candidate)+'\n')
(static/'source_sha256.json').write_text(json.dumps({path:sha(child/path) for path in files},indent=2)+'\n')
(static/'static.json').write_text(json.dumps({'status':'PASS','checks':checks,'syntax_files':20,'protected_trees_identical':protected},indent=2)+'\n')
versions={name:importlib.metadata.version(name) for name in ['torch','pytest','ruff','transformers','numpy','einops','torchvision']}
(base/'environment.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'versions':versions,'new_dependency_installation':False,'existing_kernel_identity_fixture':'explicit /proc clock identity double in transaction CPU tests; not native-host preflight','real_gpu':False,'real_DCP':False,'runtime_compatibility':'Python3.10 add_note-absent branch simulated on Python3.12, no separate Python3.10 run'},indent=2)+'\n')
summary={
    'status':'AUTHOR_TARGETED_CPU_PASS','candidate_child':candidate,'baseline_child':baseline_child,
    'root_integration_context':context,'baseline_root_at_start':baseline_root,'root_gitlink_unchanged':baseline_child,
    'matching_new_root_child_pair':False,'root_expected_worktree_gitlink_drift':True,'child_clean':True,
    'tests':428,'new_tests':155,'prior_tests':273,'failures':0,'errors':0,'skipped':0,'shell_exit':0,
    'source_unchanged':True,'source_fingerprint_entries':1273,'new_test_counts':counts,
    'independent_encode1_per_16_history':15,'completed_updates_per_16_history':16,
    'current_visual_capture':'full padded PRE-CROP Wan return; exact T1 input/output and Visual96 CPU proof',
    'numeric_witnesses':properties,'stages':stage_summaries,'static_status':'PASS','changed_child_python_files':files,
    'protected_trees_identical':protected,'pipeline_metrics':'bounded recent nearest-rank P50/P95; CUDA events finalized before elapsed_time; CPU source labelled',
    'GPU_DCP_FSDP_capture_full_Local_TTT':'NOT_RUN','real_H100_RoboCasa_before_after_latency_Ep_per_hour':'OPEN_NOT_AUTHORIZED',
    'L2000_L4000_shared_source_results_checkpoints':'NOT_ACCESSED_OR_MODIFIED','No_TTT_related_regressions':'PASS',
    'official_V3_Gitlink_update':'NOT_PERFORMED','independent_GPT_Code_Gate':'PENDING',
}
(base/'final_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert not git(child,'status','--porcelain') and git(root,'status','--porcelain')=='M cosmos-framework'
out=root/'artifacts/local_ttt_pipeline/2026-11-07_issue22_cpu'
out.mkdir(parents=True,exist_ok=False)

def include(info):
    if info.issym() or any(part in ('cache','__pycache__','.pytest_cache','.ruff_cache') for part in Path(info.name).parts):
        return None
    return info

archive=out/'cpu_evidence.tar.gz'
with tarfile.open(archive,'w:gz',dereference=False,compresslevel=6) as tar:
    tar.add(base,arcname='cpu_evidence',filter=include)
manifest={'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)}
(out/'archive_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for path in ['final_summary.json','environment.json','targeted_files.json']:
    shutil.copyfile(base/path,out/path)
shutil.copytree(static,out/'final-static')
for stage in stage_summaries:
    target=out/stage
    target.mkdir()
    for name in ['summary.json','junit.xml','pytest.log','command.json']:
        shutil.copyfile(base/stage/name,target/name)
(out/'numeric_witnesses.json').write_text(json.dumps(properties,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key not in ('numeric_witnesses','changed_child_python_files','protected_trees_identical','stages','new_test_counts')},indent=2))
print(json.dumps(manifest,indent=2))
