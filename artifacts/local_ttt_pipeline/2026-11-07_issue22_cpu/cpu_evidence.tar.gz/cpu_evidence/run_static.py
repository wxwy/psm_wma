"""Scoped author checks only; no project imports, training or GPU access."""
from pathlib import Path
import ast
import subprocess
import json
import sys

root = Path('/workspace/work/psm-wma-local-ttt-pipeline-issue22/cosmos-framework')
output = Path(sys.argv[1])
output.mkdir(parents=True, exist_ok=False)
files = sorted(set(
    subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=root,text=True).splitlines()
    + subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
))
files = [name for name in files if name.endswith('.py')]
assert files and all(name.startswith(('cosmos_framework/inference/','cosmos_framework/scripts/','cosmos_framework/simulation/robocasa/')) for name in files)
report = {'files':files, 'commands':[]}
for label, options in [
    ('import_cleanup', ['-m','ruff','check','--fix','--select','I001,F401','--no-cache',*files]),
    ('format', ['-m','ruff','format','--no-cache',*files]),
    ('ruff', ['-m','ruff','check','--no-cache',*files]),
    ('format_check', ['-m','ruff','format','--check','--no-cache',*files]),
]:
    command=[sys.executable,*options]
    done=subprocess.run(command,cwd=root,capture_output=True,text=True)
    (output/(label+'.log')).write_text(done.stdout+done.stderr)
    report['commands'].append({'name':label,'command':command,'exit_code':done.returncode})
    print(label,done.returncode,done.stdout[-4500:],done.stderr[-500:],flush=True)
    if done.returncode:
        (output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
        raise SystemExit(done.returncode)
for name in files:
    ast.parse((root/name).read_bytes())
report.update(status='PASS',syntax_files=len(files))
(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','syntax_files':len(files)}))
