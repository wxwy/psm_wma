"""Run the frozen targeted file list through the original CPU recorder."""
from pathlib import Path
import json
import subprocess
import sys

base = Path('/workspace/work/issue22-pipeline-evidence')
root = Path('/workspace/work/psm-wma-local-ttt-pipeline-issue22')
files = json.loads((base/'targeted_files.json').read_text())
assert all((root/path).is_file() for path in files)
raise SystemExit(subprocess.call([sys.executable,str(base/'run_cpu.py'),str(root),sys.argv[1],*files]))
