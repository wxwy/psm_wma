"""Collect only this locally generated CPU evidence after an exact-pair PASS."""

import argparse
import hashlib
import json
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path


def sha(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("--root-sha", required=True)
parser.add_argument("--gate", required=True, type=Path)
parser.add_argument("--archive", required=True, type=Path)
args = parser.parse_args()
source = Path("/workspace/work/psm-wma-streaming-m32")
evidence = Path("/workspace/work/eval-streaming-m32-evidence")
child_sha = "82fa270e8cdb76b3e1a4e94adf0c7ce2b497884e"
gate = json.loads((args.gate / "gate.json").read_bytes())
assert gate["status"] == "PASS" and gate["source_unchanged"] is True
assert gate["identities"] == dict(root=args.root_sha, child=child_sha, gitlink=child_sha)
assert all(step["exit_code"] == 0 for step in gate["steps"])
assert all(gate["junit"][key] == 0 for key in ("failures", "errors", "skipped"))
for directory, expected in ((source, args.root_sha), (source / "cosmos-framework", child_sha)):
    assert subprocess.check_output(["git", "-C", str(directory), "rev-parse", "HEAD"], text=True).strip() == expected
    assert not subprocess.check_output(["git", "-C", str(directory), "status", "--porcelain=v1"], text=True).strip()
watched = json.loads((args.gate / "source_sha256.json").read_bytes())
assert all(sha(source / name) == expected for name, expected in watched.items())
cases = list(ET.parse(args.gate / "junit.xml").getroot().iter("testcase"))
assert len(cases) == gate["junit"]["tests"]
assert len({(c.get("classname"), c.get("name")) for c in cases}) == len(cases)
pipelines = []
for witness in sorted((args.gate / "streaming_tmp").glob("test_18_real_tasks_64_sim_sess[0-9]*/cpu_pipeline.json")):
    record = json.loads(witness.read_bytes())
    assert record["slots"] == 64 and record["sessions"] == record["valid"] == 900
    run = witness.parent / "run"
    rows = []
    for path in run.glob("tasks/*/episodes/*/result.json"):
        sealed = json.loads(path.read_bytes())
        body = sealed["body"]
        canonical = json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()
        assert hashlib.sha256(canonical).hexdigest() == sealed["sha256"]
        rows.append(body)
    assert len(rows) == len({(r["task"], r["episode"]) for r in rows}) == 900
    assert len({r["task"] for r in rows}) == 18
    assert len({r["sampling"]["physical_slot_id"] for r in rows}) == 64
    assert json.loads((run / "manifest.json").read_bytes())["scope"] == "formal900"
    predictions = [json.loads(line) for path in run.glob("tasks/*/episodes/*/predictions.jsonl") for line in path.read_text().splitlines()]
    assert len(predictions) == len({p["transaction"]["assignment"]["session_id"] for p in predictions}) == 900
    assert sum(c["size"] for c in record["native_batches"]) == 900
    assert all(1 <= c["size"] <= record["cap"] for c in record["native_batches"])
    pipelines.append({"M": 32, "B": record["cap"], "policy_owners": len(record["stats"]),
                      "physical_slots": 64, "unique_Core": 900, "unique_Sessions": 900,
                      "batch_histograms": [s["batch_histogram"] for s in record["stats"]]})
assert {p["B"] for p in pipelines} == {8, 16} and len(pipelines) == 2
summary = {"formal_root": args.root_sha, "formal_child_gitlink": child_sha,
           "gate": str(args.gate), "gate_status": gate["status"], "shell_exit": 0,
           "source_unchanged": True, "watched_source_files": len(watched), "junit": gate["junit"],
           "groups": {key: gate[key] for key in ("inference", "phase_a_regression", "phase_b_runtime", "media_replans", "streaming")},
           "pipelines": pipelines, "GPU_real_simulation_training": "NOT_RUN",
           "remote_server_files": "NOT_ACCESSED_OR_COPIED", "V3_promotion": "NOT_AUTHORIZED_OR_PERFORMED"}
(evidence / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
assert not args.archive.exists()
args.archive.parent.mkdir(parents=True, exist_ok=True)


def include(info):
    parts = Path(info.name).parts
    if any(part in ("__pycache__", ".pytest_cache", "ruff-cache", "cpu-render-ruff", "remaining-ruff") for part in parts):
        return None
    # Discard dependency caches, preserve all test ledgers, raw JUnit/logs and toy inputs.
    if len(parts) >= 3 and parts[1].startswith("author-formal-") and parts[2] == "cache":
        return None
    return info


with tarfile.open(args.archive, "w:gz", dereference=False, compresslevel=6) as output:
    output.add(evidence, arcname="cpu_evidence", filter=include)
assert args.archive.stat().st_size < 95 * 1024**2, "split evidence before GitHub publication"
manifest = dict(summary, archive=args.archive.name, archive_bytes=args.archive.stat().st_size,
                archive_sha256=sha(args.archive))
args.archive.with_suffix(args.archive.suffix + ".manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps(manifest, indent=2))
