"""Cross-version real eager decode outputs and complete gradients, synthetic CPU only."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import subprocess

import torch

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("record", "verify"))
parser.add_argument("--evidence", required=True, type=Path)
args = parser.parse_args()
args.evidence.mkdir(exist_ok=False)
module = importlib.import_module("cosmos_framework.model.generator.mot.action_decode_compile_test")
base = Path("/workspace/work/action-decode-evidence")
golden = base / "old_eager_numerics.pt"
source = Path(module.__file__).with_name("cosmos3_vfm_network.py")
metadata = dict(production_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                test_sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
                child=subprocess.check_output(["git", "-C", str(source.parent), "rev-parse", "HEAD"], text=True).strip(),
                torch=str(torch.__version__), action_dim=15, horizon=16)
records = {}
for dtype in (torch.float32, torch.bfloat16):
    for projector in module.ACTION_IO_PROJECTOR_TYPES:
        for embedding in (False, True):
            for local_memory in (False, True):
                for kind in ("noisy", "clean", "none", "tokens_none"):
                    model = module.tiny_decode_model(dtype=dtype, projector=projector, embedding=embedding, local_memory=local_memory)
                    packed, hidden = module.decode_case(3, kind=kind, ragged=True, framewise=True)
                    hidden = hidden.detach().to(dtype).requires_grad_()
                    identities = {name: id(value) for name, value in model.named_parameters()}
                    outputs = module.decode(model, packed, hidden)
                    sum(value.float().square().sum() for value in outputs).backward()
                    assert identities == {name: id(value) for name, value in model.named_parameters()}
                    tokens = [] if packed.action is None or packed.action.tokens is None else packed.action.tokens
                    records[f"{dtype}/{projector}/{embedding}/{local_memory}/{kind}"] = dict(
                        output=[value.detach() for value in outputs], hidden_grad=hidden.grad,
                        token_grads=[token.grad for token in tokens],
                        parameter_grads={name: value.grad for name, value in model.named_parameters()},
                        state_keys=list(model.state_dict()),
                    )
if args.mode == "record":
    assert not golden.exists()
    torch.save(dict(metadata=metadata, records=records), golden)
else:
    old = torch.load(golden, weights_only=True)
    assert records.keys() == old["records"].keys()
    def equal(actual, expected):
        assert (actual is None) == (expected is None)
        if actual is not None:
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    for key, record in records.items():
        expected = old["records"][key]
        assert len(record["output"]) == len(expected["output"])
        for actual, reference in zip(record["output"], expected["output"]):
            equal(actual, reference)
        equal(record["hidden_grad"], expected["hidden_grad"])
        assert record["state_keys"] == expected["state_keys"]
        assert record["parameter_grads"].keys() == expected["parameter_grads"].keys()
        for name, value in record["parameter_grads"].items():
            equal(value, expected["parameter_grads"][name])
        for actual, reference in zip(record["token_grads"], expected["token_grads"]):
            equal(actual, reference)
    metadata["baseline_metadata"] = old["metadata"]
summary = dict(status="PASS", mode=args.mode, cases=len(records),
               exact_output_and_gradient_parity=args.mode == "verify",
               golden_sha256=hashlib.sha256(golden.read_bytes()).hexdigest(), **metadata)
(args.evidence / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
