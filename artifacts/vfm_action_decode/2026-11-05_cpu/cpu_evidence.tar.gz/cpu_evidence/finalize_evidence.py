"""Verify the frozen decode-only delta and package locally generated CPU evidence.

This external collector does not import the project or rerun project tests.
"""

import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument("--expected-root", required=True)
parser.add_argument("--expected-child", required=True)
parser.add_argument("--expected-tests", type=int, default=77)
parser.add_argument("--expected-new-tests", type=int, default=26)
parser.add_argument("--expected-test-sha256", default="a3f8b194bd4cc6145b0d97fd68c308479cd61f8918beabe40adcdd7abab64554")
args = parser.parse_args()
for value in (args.expected_root, args.expected_child):
    assert re.fullmatch(r"[0-9a-f]{40}", value), "complete frozen SHA required"

root = Path("/workspace/work/psm-wma-action-decode")
child = root / "cosmos-framework"
base = Path("/workspace/work/action-decode-evidence")
old_root = "c9fa60b7134fda8fb848c29c148f25c7a8901892"
old_child = "4e9c8104ffd15a373b576bc35ee608de1b60eea1"
prefix = "cosmos_framework/model/generator/mot/"
files = [prefix + name for name in (
    "action_decode_compile_test.py", "cosmos3_vfm_network.py",
    "parallelize_vfm_network.py", "parallelize_vfm_network_test.py",
)]
encode_test = prefix + "action_encode_compile_test.py"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(directory, *command):
    return subprocess.check_output(["git", "-C", str(directory), *command], text=True).strip()


def git_bytes(directory, revision, path):
    return subprocess.check_output(["git", "-C", str(directory), "show", revision + ":" + path])


def method(tree, name):
    return next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == name)


def code_body(function):
    body = function.body
    return body[1:] if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str) else body


def dump_body(body):
    return ast.dump(ast.Module(body=body, type_ignores=[]))


assert git(root, "rev-parse", "HEAD") == args.expected_root
assert git(child, "rev-parse", "HEAD") == git(root, "rev-parse", "HEAD:cosmos-framework") == args.expected_child
assert not git(root, "status", "--porcelain") and not git(child, "status", "--porcelain")
subprocess.check_call(["git", "-C", str(root), "merge-base", "--is-ancestor", old_root, args.expected_root])
subprocess.check_call(["git", "-C", str(child), "merge-base", "--is-ancestor", old_child, args.expected_child])
assert git(child, "diff", "--name-only", old_child, args.expected_child).splitlines() == files
root_delta = git(root, "diff", "--name-only", old_root, args.expected_root).splitlines()
assert "cosmos-framework" in root_delta
assert all(path in ("SESSION.md", "TODO.md", "cosmos-framework") or path.startswith("docs/") for path in root_delta)
assert (child / encode_test).read_bytes() == git_bytes(child, old_child, encode_test)
old_source = (base / "old_network.py").read_bytes()
assert old_source == git_bytes(child, old_child, files[1])
old_tree, new_tree = ast.parse(old_source), ast.parse((child / files[1]).read_bytes())
old_decode = method(old_tree, "_decode_action")
new_decode = method(new_tree, "_decode_action")
replacement_body = copy.deepcopy(code_body(old_decode))
replaced = 0
for node in ast.walk(ast.Module(body=replacement_body, type_ignores=[])):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "self" and node.func.attr == "llm2action":
        node.func.attr = "_project_action_predictions"
        replaced += 1
assert replaced == 2 and dump_body(replacement_body) == dump_body(code_body(new_decode))
helper = method(new_tree, "_project_action_predictions")
helper_body = code_body(helper)
assert len(helper.args.args) == 3 and helper.args.vararg is None and helper.args.kwarg is None
assert len(helper_body) == 1 and isinstance(helper_body[0], ast.Return)
projection = helper_body[0].value
assert isinstance(projection, ast.Call) and isinstance(projection.func, ast.Attribute)
assert isinstance(projection.func.value, ast.Name) and projection.func.value.id == "self" and projection.func.attr == "llm2action"
assert [ast.dump(value) for value in projection.args] == [ast.dump(ast.Name(id=arg.arg, ctx=ast.Load())) for arg in helper.args.args[1:]]
assert not projection.keywords
for name in ("_encode_action", "_project_action_tokens"):
    assert ast.dump(method(old_tree, name)) == ast.dump(method(new_tree, name)), name

old_parallelize = (base / "old_parallelize.py").read_bytes()
assert old_parallelize == git_bytes(child, old_child, files[2])
old_install = method(ast.parse(old_parallelize), "apply_compile")
new_install = method(ast.parse((child / files[2]).read_bytes()), "apply_compile")
old_install_body = copy.deepcopy(code_body(old_install))
retargeted = 0
for node in old_install_body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Attribute) and node.targets[0].attr == "_decode_action":
        assert isinstance(node.value, ast.Call) and len(node.value.args) == 1 and isinstance(node.value.args[0], ast.Attribute)
        assert node.value.args[0].attr == "_decode_action"
        node.targets[0].attr = node.value.args[0].attr = "_project_action_predictions"
        retargeted += 1
assert retargeted == 1 and dump_body(old_install_body) == dump_body(code_body(new_install))
old_scope = method(ast.parse(git_bytes(child, old_child, files[3])), "test_vfm_heads_follow_the_cuda_graph_scope")
new_scope = method(ast.parse((child / files[3]).read_bytes()), "test_vfm_heads_follow_the_cuda_graph_scope")
old_asserts = [ast.dump(node) for node in ast.walk(old_scope) if isinstance(node, ast.Assert)]
new_asserts = [ast.dump(node) for node in ast.walk(new_scope) if isinstance(node, ast.Assert)]
assert all(node in new_asserts for node in old_asserts)
test_tree = ast.parse((child / files[0]).read_bytes())
long_test = method(test_tree, "test_decode_alternating_B1_to_B8_long_run_preserves_default_limit")
assert not any(isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "reset" for node in ast.walk(long_test))
source_hashes = {file: digest(child / file) for file in files}
assert source_hashes[files[0]] == args.expected_test_sha256
static = base / "formal-static"
static.mkdir(exist_ok=True)
(static / "child_delta.patch").write_text(git(child, "diff", old_child, args.expected_child) + "\n")
checks = []
for label, command in (("ruff", ["-m", "ruff", "check", "--no-cache", *files]), ("format", ["-m", "ruff", "format", "--check", "--no-cache", *files])):
    completed = subprocess.run([sys.executable, *command], cwd=child, capture_output=True, text=True)
    (static / (label + ".log")).write_text(completed.stdout + completed.stderr)
    assert completed.returncode == 0, completed.stdout + completed.stderr
    checks.append(dict(name=label, command=[sys.executable, *command], exit_code=0))
for file in files:
    ast.parse((child / file).read_bytes())
static_report = dict(status="PASS", root=args.expected_root, child=args.expected_child,
                     baseline_root=old_root, baseline_child=old_child, child_delta=files, root_delta=root_delta,
                     sha256=source_hashes, checks=checks, syntax_files=4, decode_projection_call_replacements=2,
                     surrounding_decode_ast_identical=True, helper_only_returns_llm2action=True,
                     encode_methods_ast_identical=True, encode_test_bytes_identical=True,
                     compile_options_and_other_targets_ast_identical=True, old_scope_assertions_preserved=True,
                     no_cache_reset_inside_long_sequence=True)
(static / "static.json").write_text(json.dumps(static_report, indent=2) + "\n")


def witnesses(folder, name):
    # pytest's *current symlinks point to existing cases, not additional evidence.
    return [json.loads(path.read_text()) for path in sorted({p.resolve() for p in (folder / "pytest-temp").glob("*/" + name)})]


stages = {}
for name, expected in (("old-red", (4, 4, 1)), ("new-green", (args.expected_tests, 0, 0)), ("formal-targeted", (args.expected_tests, 0, 0))):
    folder = base / name
    report = json.loads((folder / "summary.json").read_text())
    assert (report["tests"], report["failures"], report["exit_code"]) == expected
    assert report["errors"] == report["skipped"] == 0 and report["source_unchanged"]
    cases = list(ET.parse(folder / "junit.xml").getroot().iter("testcase"))
    assert len(cases) == len({(case.get("file"), case.get("name")) for case in cases}) == expected[0]
    before = json.loads((folder / "source_before.json").read_text())
    assert before == json.loads((folder / "source_after.json").read_text())
    assert {value for key, value in before["sha256"].items() if key.endswith("action_decode_compile_test.py")} == {source_hashes[files[0]]}
    if name == "old-red":
        assert before["child"] == old_child
        assert all("FailOnRecompileLimitHit" in ET.tostring(case, encoding="unicode") for case in cases)
        assert "_decode_action" in (folder / "pytest.log").read_text()
    if name == "formal-targeted":
        assert before["root"] == args.expected_root and before["child"] == args.expected_child
        assert before["root_status"] == before["child_status"] == ""
        assert sum(case.get("file", "").endswith("action_decode_compile_test.py") for case in cases) == args.expected_new_tests
        assert re.search(rf"{args.expected_tests} passed, 8 deselected", (folder / "pytest.log").read_text())
        assert all(digest(root / path) == expected_sha for path, expected_sha in before["sha256"].items())
    records = witnesses(folder, "decode_compile_witness.json")
    assert len(records) == 4
    assert {(record["local_memory"], record["dtype"]) for record in records} == {(flag, dtype) for flag in (False, True) for dtype in ("torch.float32", "torch.bfloat16")}
    for record in records:
        assert record["recompile_limit"] == 8 and record["action_dim"] == 15 and record["normal_horizon"] == 16
        if name == "old-red":
            assert (record["calls_completed"], record["graph_count"]) == (8, 8)
            assert "_decode_action" in record["compile_targets"]
        else:
            assert record["calls_completed"] == 1024 and 1 <= record["graph_count"] <= 3
            assert "_project_action_predictions" in record["compile_targets"] and "_decode_action" not in record["compile_targets"]
            assert "_project_action_tokens" in record["compile_targets"]
    stages[name] = dict(**report, identities={key: before[key] for key in ("root", "child", "gitlink", "root_status", "child_status")}, long_sequences=records)
inductor = witnesses(base / "formal-targeted", "decode_inductor_witness.json")
assert len(inductor) == 2
assert {record["dtype"] for record in inductor} == {"torch.float32", "torch.bfloat16"}
assert all(record["calls"] == 32 and 1 <= record["graph_count"] <= 3 and record["recompile_limit"] == 8 and record["action_dim"] == 15 and record["normal_horizon"] == 16 for record in inductor)
numerics = {name: json.loads((base / name / "summary.json").read_text()) for name in ("old-eager", "new-eager", "formal-eager")}
assert all(record["cases"] == 96 and record["status"] == "PASS" and record["action_dim"] == 15 and record["horizon"] == 16 for record in numerics.values())
assert numerics["old-eager"]["child"] == old_child and numerics["old-eager"]["mode"] == "record"
assert numerics["formal-eager"]["child"] == args.expected_child
assert all(record["mode"] == "verify" and record["exact_output_and_gradient_parity"] for name, record in numerics.items() if name != "old-eager")
assert all(record["test_sha256"] == source_hashes[files[0]] for record in numerics.values())
golden_sha = digest(base / "old_eager_numerics.pt")
assert all(record["golden_sha256"] == golden_sha for record in numerics.values())
assert numerics["old-eager"]["production_sha256"] == hashlib.sha256(old_source).hexdigest()
assert numerics["formal-eager"]["production_sha256"] == source_hashes[files[1]]

summary = dict(status="AUTHOR_TARGETED_CPU_PASS", formal_root=args.expected_root, formal_child_gitlink=args.expected_child,
               baseline_root=old_root, baseline_child=old_child, tests=args.expected_tests, new_cases=args.expected_new_tests,
               failures=0, errors=0, skipped=0, deselected_gpu_l1=8, shell_exit=0, source_unchanged=True,
               source_files=stages["formal-targeted"]["source_files"], old_red_expected_failures=4,
               action_dim=15, normal_horizon=16, recompile_limit_unchanged=8, long_requests_per_case=1024,
               dynamo_graph_counts=[record["graph_count"] for record in stages["formal-targeted"]["long_sequences"]],
               cpu_inductor_graph_counts=[record["graph_count"] for record in inductor], cpu_inductor_backward_checked=True,
               eager_baseline_comparisons=96, eager_output_dtype_and_complete_gradient_bit_exact=True,
               none_vs_zero_gradients_and_parameter_identities_checked=True, static=static_report,
               test_sha256=source_hashes[files[0]], golden_sha256=golden_sha, stages=stages, numerics=numerics, inductor=inductor,
               GPU_FSDP_capture_full_Local_TTT_real_DCP="NOT_RUN", R04_R05_server_files="NOT_ACCESSED_OR_MODIFIED",
               R04_R05_Resume="NOT_RUN", Issue17_source="NOT_INCLUDED", official_V3_merge="NOT_PERFORMED", GPT_Code_Gate="PENDING")
(base / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
output = root / "artifacts/vfm_action_decode/2026-11-05_cpu"
output.mkdir(parents=True, exist_ok=False)
archive = output / "cpu_evidence.tar.gz"


def include(info):
    if info.issym() or any(part in ("cache", "__pycache__", ".pytest_cache") for part in Path(info.name).parts):
        return None
    return info


with tarfile.open(archive, "w:gz", dereference=False, compresslevel=6) as tar:
    tar.add(base, arcname="cpu_evidence", filter=include)
manifest = dict(file=archive.name, bytes=archive.stat().st_size, sha256=digest(archive))
(output / "archive_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(output / "SHA256SUMS").write_text(f"{manifest['sha256']}  {archive.name}\n")
shutil.copyfile(base / "final_summary.json", output / "final_summary.json")
if (base / "import_probe.log").exists():
    shutil.copyfile(base / "import_probe.log", output / "import_probe.log")
shutil.copytree(static, output / "formal-static")
for stage in stages:
    target = output / stage
    target.mkdir()
    for file in ("summary.json", "command.json", "junit.xml", "pytest.log"):
        shutil.copyfile(base / stage / file, target / file)
    (target / "long_witnesses.json").write_text(json.dumps(stages[stage]["long_sequences"], indent=2) + "\n")
for stage in numerics:
    target = output / stage
    target.mkdir()
    shutil.copyfile(base / stage / "summary.json", target / "summary.json")
    if (base / (stage + ".log")).exists():
        shutil.copyfile(base / (stage + ".log"), target / "original.log")
(output / "formal-targeted/inductor_witnesses.json").write_text(json.dumps(inductor, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key not in ("stages", "numerics", "inductor", "static")}, indent=2))
print(json.dumps(manifest, indent=2))
