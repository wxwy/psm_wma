def probe_runtime(*, lock_path, asset_manifest, tasks):
    assert list(tasks) == ['CloseFridge', 'NavigateKitchen']
    return {'digest': 'expected', 'protocol': {'official_horizons': {'CloseFridge': 3, 'NavigateKitchen': 450}}}
