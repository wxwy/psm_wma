"""Read-only static and exact-delta proof for NEW-F01."""
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path("/workspace/work/psm-wma-streaming-newf01")
evidence = Path("/workspace/work/eval-streaming-newf01-evidence")
out = evidence / "formal-static"
out.mkdir(exist_ok=False)
old = "00e119cc20cabe082974bd3495474b589c4b46b6"
formal = "551b03621507dde52303f54290d4fea89d66e8da"
child = "82fa270e8cdb76b3e1a4e94adf0c7ce2b497884e"
files = ["scripts/robocasa_eval_v2/startup.py", "tools/v3/eval_v2_streaming_tests/startup_completion_test.py"]

def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args])

assert git("rev-parse", "HEAD").decode().strip() == formal
assert not git("status", "--porcelain").strip()
assert git("ls-tree", formal, "cosmos-framework").decode().split()[2] == child
assert subprocess.check_output(["git", "-C", str(root / "cosmos-framework"), "rev-parse", "HEAD"], text=True).strip() == child
assert not subprocess.check_output(["git", "-C", str(root / "cosmos-framework"), "status", "--porcelain"], text=True).strip()
delta = git("diff", "--name-only", old, formal, "--", "scripts", "tools", "cosmos-framework").decode().splitlines()
assert delta == files, delta
(out / "incremental.patch").write_bytes(git("diff", "--binary", old, formal, "--", *files))
(out / "old_startup.py").write_bytes(git("show", old + ":" + files[0]))
checks = []
for name, args in (
    ("ruff", [sys.executable, "-m", "ruff", "check", "--no-cache", *files]),
    ("format", [sys.executable, "-m", "ruff", "format", "--check", "--no-cache", *files]),
    ("diff-check", ["git", "diff", old, formal, "--check"]),
):
    result = subprocess.run(args, cwd=root, capture_output=True, text=True)
    (out / (name + ".log")).write_text(result.stdout + result.stderr)
    checks.append(dict(name=name, command=args, exit_code=result.returncode))
    assert result.returncode == 0, result.stdout + result.stderr
hashes = {}
for file in files:
    source = (root / file).read_bytes()
    assert source == git("show", formal + ":" + file)
    ast.parse(source, filename=file)
    hashes[file] = hashlib.sha256(source).hexdigest()
assert (evidence / "startup_completion_test.py").read_bytes() == (root / files[1]).read_bytes()
old_hash = hashlib.sha256((out / "old_startup.py").read_bytes()).hexdigest()
red_before = json.loads((evidence / "old-red/source_before.json").read_text())
assert red_before["sha256"][files[0]] == old_hash
assert red_before["child"] == child
report = dict(status="PASS", root=formal, child=child, previous_formal=old,
              production_and_test_delta=delta, checks=checks, ast_parsed=files,
              sha256=hashes, old_production_sha256=old_hash,
              red_test_identical=True, unchanged_production_outside_delta=True,
              child_unchanged=True, mb_and_resource_manifest_unchanged=True,
              python=sys.version, packages={p: importlib.metadata.version(p) for p in ("pytest", "ruff", "torch")})
(out / "static.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
