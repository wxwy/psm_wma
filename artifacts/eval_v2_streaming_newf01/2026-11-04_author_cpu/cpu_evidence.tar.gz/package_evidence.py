"""Package only generated CPU evidence; exclude ephemeral capability files."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import xml.etree.ElementTree as ET

root = Path("/workspace/work/psm-wma-streaming-newf01")
base = Path("/workspace/work/eval-streaming-newf01-evidence")
output = root / "artifacts/eval_v2_streaming_newf01/2026-11-04_author_cpu"
output.mkdir(parents=True, exist_ok=False)
bundle = base / "bundle"
bundle.mkdir(exist_ok=False)
stages = {}
for stage, expected in (("old-red", (0, 4, 1)), ("new-green", (33, 2, 1)),
                        ("os-green", (2, 0, 0)), ("formal-targeted", (35, 0, 0))):
    folder = base / stage
    summary = json.loads((folder / "summary.json").read_text())
    assert (summary["passed"], summary["failures"], summary["exit_code"]) == expected
    assert summary["errors"] == summary["skipped"] == 0 and summary["source_unchanged"]
    cases = list(ET.parse(folder / "junit.xml").getroot().iter("testcase"))
    assert len(cases) == summary["tests"]
    before = json.loads((folder / "source_before.json").read_text())
    if stage == "formal-targeted":
        assert before["root"] == "551b03621507dde52303f54290d4fea89d66e8da"
        assert before["child"] == "82fa270e8cdb76b3e1a4e94adf0c7ce2b497884e"
        assert before["root_status"] == before["child_status"] == ""
    stages[stage] = dict(**summary, root=before["root"], child=before["child"],
                         root_status=before["root_status"], cases=[case.get("name") for case in cases])
    for file in ("summary.json", "command.json", "junit.xml", "pytest.log", "source_before.json", "source_after.json"):
        target = bundle / stage / file
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(folder / file, target)
    patterns = (
        "pytest-temp/**/newf01_os_evidence.json",
        "pytest-temp/**/run/logs/*.log",
        "pytest-temp/**/run/_internal/processes/*.json",
        "pytest-temp/**/run/_internal/process_closed/*.json",
        "pytest-temp/**/run/_internal/runtime/final_owned_cleanup_*.json",
        "pytest-temp/**/run/_internal/tasks/*/errors/*.json",
        "pytest-temp/**/run/_internal/tasks/*/cleanup/*.json",
        "pytest-temp/**/run/_internal/cpu_streaming_startup/**/*",
    )
    for pattern in patterns:
        for source in folder.glob(pattern):
            if source.is_file():
                target = bundle / stage / source.relative_to(folder)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
    # Small raw files also remain directly browseable on GitHub.
    for file in ("summary.json", "junit.xml", "pytest.log", "command.json"):
        target = output / stage / file
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(folder / file, target)

for stage in ("os-green", "formal-targeted"):
    proofs = [json.loads(p.read_text()) for p in (base / stage).glob("pytest-temp/**/newf01_os_evidence.json")]
    assert sorted(p["mode"] for p in proofs) == ["off", "required"]
    for proof in proofs:
        assert proof["both_slots_active"] and proof["all_owned_processes_closed"] and proof["outsider_alive"]
        assert proof["valid_cores"] == proof["pending_reservations"] == proof["active_jobs"] == 0
        assert len(proof["processes"]) == 3 and "BLOCKED_RESOURCE: startup RSS" in proof["error"]
    (output / stage / "os_proofs.json").write_text(json.dumps(proofs, indent=2) + "\n")

shutil.copytree(base / "formal-static", bundle / "formal-static")
for file in ("run_cpu.py", "check_static.py", "package_evidence.py", "startup_completion_test.py", "peer_review.md"):
    shutil.copyfile(base / file, bundle / file)
static = json.loads((base / "formal-static/static.json").read_text())
assert static["status"] == "PASS"
for file in ("static.json", "incremental.patch", "ruff.log", "format.log", "diff-check.log"):
    shutil.copyfile(base / "formal-static" / file, output / file)
shutil.copyfile(base / "peer_review.md", output / "peer_review.md")
manifest = [{"path": str(p.relative_to(bundle)), "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(bundle.rglob("*")) if p.is_file()]
(bundle / "archive_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
archive = output / "cpu_evidence.tar.gz"
with tarfile.open(archive, "w:gz") as tar:
    for source in sorted(bundle.rglob("*")):
        if source.is_file():
            tar.add(source, arcname=str(source.relative_to(bundle)), recursive=False)
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
(output / "SHA256SUMS").write_text(f"{digest}  cpu_evidence.tar.gz\n")
report = dict(
    status="PASS", gate="NEW-F01 narrow author CPU/static only",
    formal_root=static["root"], child=static["child"], previous_formal_root=static["previous_formal"],
    targeted_passed=35, failures=0, errors=0, skipped=0, shell_exit=0,
    source_unchanged=True, source_files=stages["formal-targeted"]["source_files"],
    static_status="PASS", unchanged_child=True, unchanged_mb_resume_and_manifest=True,
    identical_red_green_test_sha256=static["sha256"]["tools/v3/eval_v2_streaming_tests/startup_completion_test.py"],
    original_red_production_sha256=static["old_production_sha256"],
    new_production_sha256=static["sha256"]["scripts/robocasa_eval_v2/startup.py"],
    full_gate_run=False, ds_independent_run=False, gpu_run=False, v3_merged=False,
    historical_author_846="not rerun; does not close NEW-F01 or new-pair Evidence Gate",
    historical_failures_retained="old-red expected4FAIL; new-green33PASS/2FAIL absent external adjacent fixture; unchanged tests/source then os-green2PASS; formal-targeted35PASS",
    archive=dict(file=archive.name, bytes=archive.stat().st_size, sha256=digest, entries=len(manifest) + 1),
    stages=stages,
)
(output / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: value for key, value in report.items() if key != "stages"}, indent=2))
