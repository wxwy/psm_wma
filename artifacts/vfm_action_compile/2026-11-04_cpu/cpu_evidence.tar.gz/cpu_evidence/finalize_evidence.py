"""Check the frozen minimal delta and preserve only locally generated CPU evidence."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET

root = Path("/workspace/work/psm-wma-action-compile")
child = root / "cosmos-framework"
base = Path("/workspace/work/action-compile-evidence")
formal = "c9fa60b7134fda8fb848c29c148f25c7a8901892"
child_sha = "4e9c8104ffd15a373b576bc35ee608de1b60eea1"
old_child = "1069fe78841228cadbbfbe6afbd767eaed6225da"
prefix = "cosmos_framework/model/generator/mot/"
files = [prefix + name for name in ("action_encode_compile_test.py", "cosmos3_vfm_network.py", "parallelize_vfm_network.py", "parallelize_vfm_network_test.py")]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(directory, *args):
    return subprocess.check_output(["git", "-C", str(directory), *args], text=True).strip()


def method(source, name):
    tree = ast.parse(source)
    return next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == name)


assert git(root, "rev-parse", "HEAD") == formal
assert git(child, "rev-parse", "HEAD") == git(root, "rev-parse", "HEAD:cosmos-framework") == child_sha
assert not git(root, "status", "--porcelain") and not git(child, "status", "--porcelain")
assert git(child, "diff", "--name-only", old_child, child_sha).splitlines() == files
root_delta = git(root, "diff", "--name-only", "9635cefe3208ab6320ba5fa70b0e0d68fd444790", formal).splitlines()
assert set(root_delta) == {"SESSION.md", "TODO.md", "cosmos-framework", "docs/collab/codex/designs/2026-11-04_VFM_Action_Dynamic_Compile_Narrow_Design.md"}
static = base / "formal-static"
static.mkdir(exist_ok=True)
(static / "child_delta.patch").write_text(git(child, "diff", old_child, child_sha) + "\n")
old_source = (base / "old_network.py").read_text()
new_source = (child / files[1]).read_text()
assert old_source == subprocess.check_output(["git", "-C", str(child), "show", old_child + ":" + files[1]], text=True)
old_body = method(old_source, "_encode_action").body
new_body = method(new_source, "_encode_action").body
projection = method(new_source, "_project_action_tokens").body[1:-1]
index = next(i for i, node in enumerate(old_body) if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == "to")
replacement = next(node for node in new_body if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == "_project_action_tokens")
def dump(nodes):
    return ast.dump(ast.Module(body=nodes, type_ignores=[]))
assert dump(projection) == dump(old_body[index:index + 3])
assert dump(new_body) == dump(old_body[:index] + [replacement] + old_body[index + 3:])
old_compile = ast.parse((base / "old_parallelize.py").read_text())
new_compile = ast.parse((child / files[2]).read_text())
def options(tree):
    return next(node.value for node in ast.walk(tree) if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "compile_options" for target in node.targets))
assert ast.dump(options(old_compile)) == ast.dump(options(new_compile))
checks = []
for label, args in (("ruff", ["-m", "ruff", "check", "--no-cache", *files]), ("format", ["-m", "ruff", "format", "--check", "--no-cache", *files])):
    result = subprocess.run([sys.executable, *args], cwd=child, capture_output=True, text=True)
    (static / (label + ".log")).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stdout + result.stderr
    checks.append(dict(name=label, command=[sys.executable, *args], exit_code=0))
for file in files:
    ast.parse((child / file).read_text())
source_hashes = {file: digest(child / file) for file in files}
static_report = dict(status="PASS", root=formal, child=child_sha, old_child=old_child,
                     child_delta=files, root_delta=root_delta, sha256=source_hashes, checks=checks,
                     projection_math_ast_identical=True, surrounding_encode_ast_identical=True,
                     compile_options_ast_identical=True, syntax_files=len(files))
(static / "static.json").write_text(json.dumps(static_report, indent=2) + "\n")

stages = {}
for name, expected in (("old-red", (4, 4, 1)), ("new-green", (51, 0, 0)), ("formal-targeted", (51, 0, 0))):
    folder = base / name
    summary = json.loads((folder / "summary.json").read_text())
    assert (summary["tests"], summary["failures"], summary["exit_code"]) == expected
    assert summary["errors"] == summary["skipped"] == 0 and summary["source_unchanged"]
    cases = list(ET.parse(folder / "junit.xml").getroot().iter("testcase"))
    assert len(cases) == len({(case.get("classname"), case.get("name")) for case in cases}) == expected[0]
    before = json.loads((folder / "source_before.json").read_text())
    assert before == json.loads((folder / "source_after.json").read_text())
    watched_test = {value for key, value in before["sha256"].items() if key.endswith("action_encode_compile_test.py")}
    assert watched_test == {source_hashes[files[0]]}
    if name == "formal-targeted":
        assert before["root"] == formal and before["child"] == child_sha
        assert before["root_status"] == before["child_status"] == ""
        assert sum(case.get("file", "").endswith("action_encode_compile_test.py") for case in cases) == 19
        assert "51 passed, 8 deselected" in (folder / "pytest.log").read_text()
    witnesses = [json.loads(path.read_text()) for path in sorted({p.resolve() for p in (folder / "pytest-temp").glob("*/action_compile_witness.json")})]
    assert len(witnesses) == 4
    for record in witnesses:
        assert record["recompile_limit"] == 8
        assert (record["calls_completed"], record["graph_count"]) == ((8, 8) if name == "old-red" else (1024, 1))
    if name == "old-red":
        assert all("FailOnRecompileLimitHit" in ET.tostring(case, encoding="unicode") for case in cases)
    stages[name] = dict(**summary, identities={key: before[key] for key in ("root", "child", "gitlink", "root_status", "child_status")}, long_sequences=witnesses)
inductor = [json.loads(path.read_text()) for path in sorted({p.resolve() for p in (base / "formal-targeted/pytest-temp").glob("*/inductor_witness.json")})]
assert len(inductor) == 2 and all(record["calls"] == 32 and record["graphs"] == 2 for record in inductor)
numerics = {name: json.loads((base / name / "summary.json").read_text()) for name in ("old-eager", "new-eager", "formal-eager")}
assert all(record["cases"] == 12 and record["status"] == "PASS" for record in numerics.values())
assert numerics["formal-eager"]["child"] == child_sha
assert numerics["formal-eager"]["exact_output_and_gradient_parity"]
assert all(record["test_sha256"] == source_hashes[files[0]] for record in numerics.values())
assert all(record["golden_sha256"] == digest(base / "old_eager_numerics.pt") for record in numerics.values())

summary = dict(status="AUTHOR_TARGETED_CPU_PASS", formal_root=formal, formal_child_gitlink=child_sha,
               baseline_root="9635cefe3208ab6320ba5fa70b0e0d68fd444790", baseline_child=old_child,
               tests=51, failures=0, errors=0, skipped=0, deselected_gpu_l1=8, new_cases=19,
               shell_exit=0, source_unchanged=True, source_files=stages["formal-targeted"]["source_files"],
               old_red_expected_failures=4, recompile_limit_unchanged=8, long_requests_per_case=1024,
               dynamo_graphs_per_long_case=1, cpu_inductor_graphs_per_case=2,
               eager_baseline_comparisons=12, eager_output_gradient_bit_exact=True,
               projection_math_ast_identical=True, compile_options_ast_identical=True,
               test_sha256=source_hashes[files[0]], golden_sha256=digest(base / "old_eager_numerics.pt"),
               stages=stages, numerics=numerics, inductor=inductor,
               GPU_FSDP_capture_full_Local_TTT_real_checkpoint="NOT_RUN",
               R04_server_files="NOT_ACCESSED_OR_MODIFIED", R04_Resume="NOT_RUN",
               Issue17_source="NOT_INCLUDED", official_V3_merge="NOT_PERFORMED", GPT_Code_Gate="PENDING")
(base / "final_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
output = root / "artifacts/vfm_action_compile/2026-11-04_cpu"
output.mkdir(parents=True, exist_ok=False)
archive = output / "cpu_evidence.tar.gz"
def include(info):
    if info.issym() or any(part in ("cache", "__pycache__", ".pytest_cache") for part in Path(info.name).parts):
        return None
    return info
with tarfile.open(archive, "w:gz", dereference=False, compresslevel=6) as tar:
    tar.add(base, arcname="cpu_evidence", filter=include)
manifest = dict(file=archive.name, bytes=archive.stat().st_size, sha256=digest(archive))
(output / "archive_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(output / "SHA256SUMS").write_text(f"{manifest['sha256']}  {archive.name}\n")
for file in ("final_summary.json", "import_probe.log"):
    shutil.copyfile(base / file, output / file)
shutil.copytree(static, output / "formal-static")
for stage in ("old-red", "new-green", "formal-targeted"):
    target = output / stage
    target.mkdir()
    for file in ("summary.json", "command.json", "junit.xml", "pytest.log"):
        shutil.copyfile(base / stage / file, target / file)
    witnesses = stages[stage]["long_sequences"]
    (target / "long_witnesses.json").write_text(json.dumps(witnesses, indent=2) + "\n")
for stage in numerics:
    target = output / stage
    target.mkdir()
    shutil.copyfile(base / stage / "summary.json", target / "summary.json")
    shutil.copyfile(base / (stage + ".log"), target / "original.log")
(output / "formal-targeted/inductor_witnesses.json").write_text(json.dumps(inductor, indent=2) + "\n")
print(json.dumps({key: value for key, value in summary.items() if key not in ("stages", "numerics", "inductor")}, indent=2))
print(json.dumps(manifest, indent=2))
