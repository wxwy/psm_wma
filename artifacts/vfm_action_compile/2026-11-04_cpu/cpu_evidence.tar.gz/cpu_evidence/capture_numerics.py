"""Capture/verify actual eager Action outputs and gradients across source versions."""
import argparse
import copy
import hashlib
import importlib
import json
from pathlib import Path
import subprocess

import torch

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("record", "verify"))
parser.add_argument("--evidence", required=True, type=Path)
args = parser.parse_args()
args.evidence.mkdir(exist_ok=False)
module = importlib.import_module("cosmos_framework.model.generator.mot.action_encode_compile_test")
golden = Path("/workspace/work/action-compile-evidence/old_eager_numerics.pt")
source = Path(module.__file__).with_name("cosmos3_vfm_network.py")
metadata = dict(production_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                test_sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest(),
                child=subprocess.check_output(["git", "-C", str(source.parent), "rev-parse", "HEAD"], text=True).strip(),
                torch=str(torch.__version__))
records = {}
for dtype in (torch.float32, torch.bfloat16):
    for projector in module.ACTION_IO_PROJECTOR_TYPES:
        for embedding in (False, True):
            model = module.tiny_model(dtype=dtype, projector=projector, embedding=embedding)
            packed = module.action_case(5, noisy=True, ragged=True, framewise=True, single_timestep=True)
            output = module.encode(model, packed, dtype)
            output.float().square().sum().backward()
            records[f"{dtype}/{projector}/{embedding}"] = dict(
                output=output.detach(),
                token_grads=[token.grad for token in packed.action.tokens],
                parameter_grads={name: value.grad for name, value in model.named_parameters() if value.grad is not None},
                state_keys=list(model.state_dict()),
            )
if args.mode == "record":
    assert not golden.exists()
    torch.save(dict(metadata=metadata, records=records), golden)
else:
    old = torch.load(golden, weights_only=True)
    assert records.keys() == old["records"].keys()
    for key, record in records.items():
        expected = old["records"][key]
        torch.testing.assert_close(record["output"], expected["output"], rtol=0, atol=0)
        assert record["state_keys"] == expected["state_keys"]
        assert record["parameter_grads"].keys() == expected["parameter_grads"].keys()
        for name, value in record["parameter_grads"].items():
            torch.testing.assert_close(value, expected["parameter_grads"][name], rtol=0, atol=0)
        for actual, reference in zip(record["token_grads"], expected["token_grads"]):
            torch.testing.assert_close(actual, reference, rtol=0, atol=0)
    metadata["baseline_metadata"] = old["metadata"]
summary = dict(status="PASS", mode=args.mode, cases=len(records), exact_output_and_gradient_parity=True,
               golden_sha256=hashlib.sha256(golden.read_bytes()).hexdigest(), **metadata)
(args.evidence / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
