"""External evidence recorder; does not wrap or change project behavior."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root, output = map(lambda p: Path(p).resolve(), sys.argv[1:3])
output.mkdir(parents=True, exist_ok=False)
python = "/workspace/.venvs/psm-wma-cpu/bin/python"
environment = dict(os.environ)
settings = dict(
    CUDA_VISIBLE_DEVICES="", LD_LIBRARY_PATH="", PYTHONDONTWRITEBYTECODE="1",
    COSMOS_DEVICE="cpu", MUJOCO_GL="osmesa", PYOPENGL_PLATFORM="osmesa",
    HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", OMP_NUM_THREADS="1",
    MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1",
    PYTHONPATH=os.pathsep.join(map(str, (root, root / "scripts", root / "cosmos-framework"))),
    TORCHINDUCTOR_CACHE_DIR=str(output / "cache/inductor"),
    TORCHINDUCTOR_COMPILE_THREADS="1", TRITON_CACHE_DIR=str(output / "cache/triton"),
    XDG_CACHE_HOME=str(output / "cache/xdg"), HF_HOME=str(output / "cache/hf"),
    MPLCONFIGDIR=str(output / "cache/mpl"), RUFF_CACHE_DIR=str(output / "cache/ruff"),
)
environment.update(settings)

def git(directory, *args):
    return subprocess.check_output(["git", "-C", str(directory), *args], text=True).strip()

def identity():
    hashes = {}
    for directory, paths in ((root, ("scripts", "tools/v3")), (root / "cosmos-framework", ("cosmos_framework",))):
        for name in git(directory, "ls-files", "--", *paths).splitlines():
            path = directory / name
            if path.is_file():
                hashes[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    for argument in sys.argv[3:]:
        path = Path(argument)
        if path.is_file():
            hashes[str(path.resolve())] = hashlib.sha256(path.read_bytes()).hexdigest()
    return dict(
        root=git(root, "rev-parse", "HEAD"),
        child=git(root / "cosmos-framework", "rev-parse", "HEAD"),
        gitlink=git(root, "ls-tree", "HEAD", "cosmos-framework"),
        root_status=git(root, "status", "--porcelain"),
        child_status=git(root / "cosmos-framework", "status", "--porcelain"),
        sha256=hashes,
    )

before = identity()
(output / "source_before.json").write_text(json.dumps(before, indent=2) + "\n")
command = [python, "-m", "pytest", "--noconftest", "-c", "/dev/null", "-p", "no:cacheprovider",
           "-o", "junit_family=legacy", "-q", "--basetemp", str(output / "pytest-temp"),
           "--junitxml", str(output / "junit.xml"), *sys.argv[3:]]
(output / "command.json").write_text(json.dumps(dict(cwd=str(root), command=command, environment=settings), indent=2) + "\n")
started = time.monotonic()
with (output / "pytest.log").open("w") as log:
    completed = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT)
after = identity()
(output / "source_after.json").write_text(json.dumps(after, indent=2) + "\n")
counts = {key: 0 for key in ("tests", "failures", "errors", "skipped")}
if (output / "junit.xml").exists():
    for suite in ET.parse(output / "junit.xml").getroot().iter("testsuite"):
        for key in counts:
            counts[key] += int(suite.get(key, 0))
summary = dict(exit_code=completed.returncode, elapsed_seconds=time.monotonic() - started,
               source_unchanged=before == after, source_files=len(before["sha256"]), **counts)
summary["passed"] = counts["tests"] - counts["failures"] - counts["errors"] - counts["skipped"]
summary["status"] = "PASS" if completed.returncode == 0 and before == after and not any(counts[k] for k in ("failures", "errors", "skipped")) else "FAIL"
(output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
print((output / "pytest.log").read_text()[-3000:], flush=True)
raise SystemExit(completed.returncode or (0 if before == after else 3))
