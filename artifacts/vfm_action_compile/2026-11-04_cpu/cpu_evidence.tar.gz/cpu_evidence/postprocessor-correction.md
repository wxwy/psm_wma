# External postprocessor correction

The first finalize_evidence.py invocation exited1 at its new-case classification
assertion. Raw legacy-family JUnit from `-c /dev/null` has classname="" and a
correct `file` attribute. Its actual51 cases/zero failures were already complete.
The collector incorrectly expected the source module name in `classname`.

Preserve finalize_evidence_initial.py as that exact initial checker. Correct only
the postprocessor classification to count `file.endswith(action_encode_compile_test.py)`
and allow reusing its already-created formal-static metadata folder. All original
JUnit/log/source fingerprints and production/test files remain unchanged. No
test was rerun for this correction. The corrected collector still requires19 new
cases,51 unique total cases, zero failures/errors/skips, exact source identity,
all counter witnesses and old/new numeric reference equality reports.

Initial traceback:

    File "/workspace/work/action-compile-evidence/finalize_evidence.py", line 92
      assert sum(case.get("classname", "").endswith("action_encode_compile_test") for case in cases) == 19
    AssertionError
