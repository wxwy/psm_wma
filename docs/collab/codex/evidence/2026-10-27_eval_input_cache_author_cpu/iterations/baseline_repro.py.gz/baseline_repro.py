import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('/workspace/psm_wma');sys.path[:0]=[str(root/'scripts'),str(root)]
import robocasa_episode_resume.model_identity as module
old=subprocess.check_output(['git','show','49df7f3c2e0ba8ef5871f9dd490e41fbc3dc5da9:scripts/robocasa_episode_resume/model_identity.py'],cwd=root)
exec(compile(old,'baseline49df7f3c/model_identity.py','exec'),module.__dict__)
print(json.dumps({'exact_baseline_source_sha256':hashlib.sha256(old).hexdigest(),'scope':'original unchanged legacy bridge assertion, not cache code'}),flush=True)
import pytest
raise SystemExit(pytest.main(['--noconftest','-c','/dev/null','-p','no:cacheprovider','-q','tools/v3/robocasa_resume_components_test.py::test_legacy_bridge_keeps_original_sha_scope_and_never_rehashes_per_episode','--junitxml=/tmp/psm-v3-eval-cache-20261027/baseline_red.xml']))
